package com.deltabot

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import okhttp3.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var price: TextView
    private lateinit var status: TextView
    private var paper = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,40,32,32) }
        val title = TextView(this).apply { text="DELTA BOT"; textSize=28f; setTextColor(Color.BLACK) }
        price = TextView(this).apply { text="BTCUSD: connecting…"; textSize=22f; setPadding(0,28,0,18) }
        status = TextView(this).apply { text="PAPER MODE • Bot stopped"; textSize=18f }
        val start = Button(this).apply { text="START PAPER BOT" }
        val stop = Button(this).apply { text="STOP BOT"; isEnabled=false }
        val info = TextView(this).apply {
            text="\nStrategy V1\nEMA 20/50 • RSI 14 • VWAP\nRisk: 1% • R:R: 1:2\n\nNo real orders are placed in V1."
            textSize=16f
        }
        root.addView(title); root.addView(price); root.addView(status); root.addView(start); root.addView(stop); root.addView(info)
        setContentView(root)
        connectMarketData()
        start.setOnClickListener { paper=true; status.text="PAPER MODE • Bot running"; start.isEnabled=false; stop.isEnabled=true }
        stop.setOnClickListener { status.text="PAPER MODE • Bot stopped"; start.isEnabled=true; stop.isEnabled=false }
    }

    private fun connectMarketData() {
        val client = OkHttpClient()
        val request = Request.Builder().url("wss://public-socket.india.delta.exchange").build()
        client.newWebSocket(request, object: WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                ws.send("""{"type":"subscribe","payload":{"channels":[{"name":"ticker","symbols":["BTCUSD"]}]}}""")
            }
            override fun onMessage(ws: WebSocket, text: String) {
                try {
                    val o=JSONObject(text)
                    if(o.optString("type")=="v2/ticker" || o.optString("type")=="ticker") {
                        val p=o.optString("close").ifEmpty { o.optString("mark_price") }
                        runOnUiThread { if(p.isNotEmpty()) price.text="BTCUSD: $p" }
                    }
                } catch(_: Exception) {}
            }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { price.text="Market data connection failed" }
            }
        })
    }
}
