# DeltaBot Android V1
Paper-trading Android starter for Delta Exchange India.

This build connects to Delta's public WebSocket market feed and provides a safe paper-mode dashboard.
It does NOT place real orders.

Build with Android Studio:
1. Open this folder.
2. Let Gradle sync.
3. Run on an Android device/emulator.
4. For an APK: Build > Build APK(s).

Before live trading, add proper candle aggregation, EMA/RSI/VWAP calculations, risk engine, persistent trade logs, backend/API-key protection, and Delta testnet validation.
